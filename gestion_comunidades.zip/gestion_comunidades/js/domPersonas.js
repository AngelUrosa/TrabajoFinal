//Variables
const url = 'http://localhost/gestion_comunidades/index.php?principal=Intefaz\listadoDomPersonas.html';

const contenedor = document.querySelector('tbody')
let resultados = ''

var myModal = document.getElementById('myModal')