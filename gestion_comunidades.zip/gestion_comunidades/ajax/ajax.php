<?php

function cargarClasesPojos($nombreClases) {
    if(file_exists("pojos/".$nombreClases))
}

?>