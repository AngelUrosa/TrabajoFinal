package com.daw2.aprende.model.dao;


import com.daw2.aprende.model.entity.Departamento;
public interface DepartamentosDao extends Dao<Departamento, Integer> {
}
