package com.daw2.aprende.model.dao;

/**
 *
 * @author JAVIER
 */
public class ExceptionDataBase extends Exception {
	private static final long serialVersionUID = 1L;

    public ExceptionDataBase(String msg) {
        super(msg);
    }
}
